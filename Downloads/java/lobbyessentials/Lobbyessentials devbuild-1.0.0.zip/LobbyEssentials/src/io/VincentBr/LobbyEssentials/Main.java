package io.VincentBr.LobbyEssentials;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import net.md_5.bungee.api.ChatColor;

public class Main extends JavaPlugin implements Listener{
	
	public Inventory inv;
	
	@Override
	public void onEnable() {
		this.getServer().getPluginManager().registerEvents(this, this);
		createInv();
		this.saveDefaultConfig();
	}
	
	@Override
	public void onDisable() {
		
	}
	
	//Config reload
	/*public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (label.equalsIgnoreCase("LobbyEssentials")) {
			if (!sender.hasPermission("LobbyEssentials.reload")) {
				sender.sendMessage(ChatColor.RED + "You have no permissions to run this command!");
				return true;
			}
			if (args.length == 0) {
				sender.sendMessage(ChatColor.RED + "Usage: /LobbyEssentials reload");
				return true;
			}
			if (args.length > 0) {
				if (args [0].equalsIgnoreCase("reload")) {
						sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&6Config reloaded successfully!"));
					this.reloadConfig();
				}
			}
		}
		return false;
	} */
	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		//gui opener
		if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
			if (player.getItemInHand().getType() == Material.COMPASS) {
				player.openInventory(inv);
				return true;
			}
		}
		//worldselector command
		if (label.equalsIgnoreCase("Serverselector")) {
			if (!(sender instanceof Player)) {
				sender.sendMessage("Only players may execute this command!");
				return true;
			}
			Player player = (Player) sender;
		}
		//LobbyEssentials info command
		if (label.equalsIgnoreCase("LobbyEssentials")) {
			sender.sendMessage(org.bukkit.ChatColor.GOLD + "LobbyEssentials by Vincent Br.");
			sender.sendMessage(org.bukkit.ChatColor.GREEN + "Version: 1.0.0");
			return true;
		}
		return false;
	}
	
	//open inv
	public void openGui(final HumanEntity ent) {
		ent.openInventory(inv);
	}
	
	//Gui
	@EventHandler()
	public void onClick(InventoryClickEvent event) {
		if (!event.getCurrentItem() == null) return;
		if (!event.getCurrentItem().getItemMeta() == null) return;
		if (event.getCurrentItem().getItemMeta().getDisplayName() == null) return;
		
		event.setCancelled(true);
		
		Player player = (Player) event.getWhoClicked();
		
		if (event.getSlot() == 10 ) {
			//server selector survival
			player.performCommand("server survival");
		}
		if (event.getSlot() == 12 ) {
			//server selector creative
			player.performCommand("server creative");
		}
		if (event.getSlot() == 14 ) {
			//server selector uhc
			player.performCommand("server uhc");
		}
		if (event.getSlot() == 16 ) {
			//server selector close
			player.performCommand("server survival");
		}
	}
	
	public void createInv() {
		inv = Bukkit.createInventory(null, 27, ChatColor.AQUA + "" + ChatColor.BOLD + "ServerSelector");
		
		ItemStack item = new ItemStack(Material.GRASS_BLOCK);
		ItemMeta meta = item.getItemMeta();
		
		//survival
		meta.setDisplayName(ChatColor.RED + "Survival");
		List<String> lore = new ArrayList <String>();
		lore.add(ChatColor.GRAY + "Click to Teleport!");
		meta.setLore(lore);
		item.setItemMeta(meta);
		inv.setItem(10, item);
		
		//creative
		item.setType(Material.TNT);
		meta.setDisplayName(ChatColor.GREEN + "Creative");
		item.setItemMeta(meta);
		inv.setItem(12, item);
		
		//uhc
		item.setType(Material.BOW);
		meta.setDisplayName(ChatColor.YELLOW + "UHC");
		item.setItemMeta(meta);
		inv.setItem(14, item);
		
		//close
		item.setType(Material.BARRIER);
	}
}
